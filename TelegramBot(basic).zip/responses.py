from datetime import datetime

def sampleResponse(input_text):

    userMessage = str(input_text).lower()

    if userMessage in ("hello", "hi", "hey", "whatsup",):
        return "Hey! How is it going?"

    if userMessage in ("okay", "good", "very good", "fine",):
        return "That's nice! Do you need anything? (time, capital city)"

    if userMessage in "capital city":
        return "Which one? Choose: czech republic, austria, germany, poland, slovakia, russia, usa, italy, ukraine"

    if userMessage in "czech republic":
        return "Prague. Anything else?"

    if userMessage in "austria":
        return "Vienna. Anything else? (yes/no)"

    if userMessage in "germany":
        return "Berlin. Anything else? (yes/no)"

    if userMessage in "poland":
        return "Warsaw. Anything else? (yes/no)"

    if userMessage in "slovakia":
        return "Bratislava. Anything else? (yes/no)"

    if userMessage in "russia":
        return "Moscow. Anything else? (yes/no)"

    if userMessage in "usa":
        return "Washington, D.C. Anything else? (yes/no)"

    if userMessage in "italy":
        return "Rome. Anything else? (yes/no)"

    if userMessage in "ukraine":
        return "Kyiv. Anything else? (yes/no)"


    if userMessage in ("time"):
        now = datetime.now()
        dateTime = now.strftime("%d/%m/%y, %H:%M:%S. Anything else? (yes/no)")

        return str(dateTime)

    if userMessage in ("no"):
        return "Okay. See ya later!"

    if userMessage in "yes":
        return "Good! What is it going to be? (time, capital city)"


    return "I don't understand what you wrote. Sorry."

